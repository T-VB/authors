import { useEffect, useState } from "react";
import axios from "axios";
import { Link, useNavigate } from "react-router-dom";

const DisplayAll = () => {
  const navigate = useNavigate();
  const [authorList, setAuthorList] = useState([]);
  useEffect(() => {
    axios
      .get("http://localhost:8000/api/authors")
      .then((res) => {
        console.log(res);
        setAuthorList(res.data);
      })
      .catch((err) => {
        console.log(err.response);
      });
  }, []);

  const deleteHandler = (id) => {
    axios
      .delete(`http://localhost:8000/api/authors/${id}`)
      .then((res) => {
        console.log("success deleting author");
        navigate("/displayAll");
        const filteredAuthors = authorList.filter((author) => {
          return author._id !== id;
        });
        setAuthorList(filteredAuthors);
      })
      .catch((err) => {
        console.log(err.res, "error deleting author");
      });
  };

  return (
    <div className="container">
      <div className="row">
        <div className="col-6">
          <Link to="/createAuthor">Add an Author</Link>
          <p className="purple-text">We have quotes by:</p>
          <table className="table">
            <thead>
              <tr>
                <th scope="col">Author</th>
                <th scope="col">Actions</th>
              </tr>
            </thead>
            <tbody>
              {authorList.map((author, index) => {
                return (
                  <tr key={author._id}>
                    <td className="col col-3">{author.name}</td>
                    <td>
                      <Link to={`/updateAuthor/${author._id}`}>
                        <button className="btn btn-info">Edit</button>
                      </Link>
                      <button
                        className="btn btn-danger"
                        onClick={() => deleteHandler(author._id)}
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default DisplayAll;
