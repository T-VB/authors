import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate, useParams, Link } from "react-router-dom";

const UpdateAuthor = (props) => {
  const [author, setAuthor] = useState("");
  const navigate = useNavigate();

  //add state for errors
  const [errors, setErrors] = useState({});

  const { id } = useParams();

  useEffect(() => {
    axios
      .get(`http://localhost:8000/api/authors/${id}`)
      .then((res) => {
        console.log(res);
        setAuthor(res.data);
      })
      .catch((err) => {
        console.log(err);
      });
  }, []);

  const submitHandler = (e) => {
    e.preventDefault(); //prevents default action of page refresh and state clear, once button is clicked

    console.log("inside handler", author);

    axios
      .put(`http://localhost:8000/api/authors/${id}`, { name: author })
      .then((res) => {
        console.log(res);
        navigate("/displayAll");
      })
      .catch((err) => {
        console.log(err.response.data.errors);
        setErrors(err.response.data.errors);
      });
  };
  return (
    <div className="container">
      <div className="row">
        <div className="col-6">
          <Link to="/displayAll">Home</Link>
          <h1>Update an Author</h1>
          <form onSubmit={submitHandler}>
            <div className="form-group">
              <label htmlFor="form-label">Name:</label>
              <input
                onChange={(e) => setAuthor(e.target.value)}
                className="form-control"
                type="text"
                value={author.name}
              />
              {errors.name && (
                <span className="text-danger">{errors.name.message}</span>
              )}
            </div>
            <button type="submit" className="mt-3 btn btn-info ">
              Submit
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default UpdateAuthor;
