import React, { useState } from "react";
import axios from "axios";
import { useNavigate, Link } from "react-router-dom";

const CreateAuthor = (props) => {
  const [name, setName] = useState("");
  const navigate = useNavigate();

  //add state for errors
  const [errors, setErrors] = useState({});

  const submitHandler = (e) => {
    e.preventDefault(); //prevents default action of page refresh and state clear, once button is clicked

    axios
      .post("http://localhost:8000/api/authors", { name })
      .then((res) => {
        console.log(res);
        navigate("/displayAll");
      })
      .catch((err) => {
        console.log(err.response.data.errors);
        setErrors(err.response.data.errors);
      });
  };
  return (
    <div className="container">
      <div className="row">
        <div className="col-6">
          <Link to="/displayAll">Home</Link>
          <h1>Add an Author</h1>
          <form onSubmit={submitHandler}>
            <div className="form-group">
              <label htmlFor="form-label">Name:</label>
              <input
                onChange={(e) => setName(e.target.value)}
                className="form-control"
                type="text"
                value={name}
              />
              {errors.name && (
                <span className="text-danger">{errors.name.message}</span>
              )}
            </div>
            <button type="submit" className="mt-3 btn btn-info ">
              Submit
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default CreateAuthor;
