import "./App.css";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import DisplayAll from "./components/DisplayAll";
import CreateAuthor from "./components/CreateAuthor";
import UpdateAuthor from "./components/UpdateAuthor";

function App() {
  return (
    <div className="App">
      <h1>Favorite Authors</h1>
      <BrowserRouter>
        {/* <NavBar /> add this as it's own component*/}
        <Routes>
          <Route path="/createAuthor" element={<CreateAuthor />} />
          <Route path="/displayAll" element={<DisplayAll />} />
          {/* <Route path="/oneAuthor/:id" element={<OneAuthor />} /> */}
          <Route path="/updateAuthor/:id" element={<UpdateAuthor />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
