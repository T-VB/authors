const AuthorsController = require("../controllers/authors.controller.js");

module.exports = (app) => {
  // app.get("/", (req, res) => {
  //   res.json({ message: "Good to Go! Route is working" });
  // });
  //^Use this app.get in POSTMAN to TEST^
  app.post("/api/authors/", AuthorsController.createAuthor);
  //^and use app.post in POSTMAN to TEST^
  app.get("/api/authors/", AuthorsController.findAll);
  app.get("/api/authors/:id", AuthorsController.findOne);
  app.put("/api/authors/:id", AuthorsController.updateAuthor);
  app.delete("/api/authors/:id", AuthorsController.deleteAuthor);
};
