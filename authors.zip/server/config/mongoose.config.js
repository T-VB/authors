const mongoose = require("mongoose");

const authorsDb = "authors";

mongoose
  .connect(`mongodb://localhost/${authorsDb}`, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => console.log(`Connected to ${authorsDb} database`))
  .catch((err) => err);
